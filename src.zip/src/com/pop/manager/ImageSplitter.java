package com.pop.manager;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageSplitter {
	public static void main(String[] args) {
        try {
            // ����ԭʼͼƬ
            BufferedImage originalImage = ImageIO.read(new File("image/Characters/Done_body16001_walk.png"));
            
            // ����ÿ��СͼƬ�Ŀ��Ⱥ͸߶�
            int width = originalImage.getWidth() / 4;
            int height = originalImage.getHeight() / 4;
            
            int[] cropParams = {
            		//down����
            		25, 42, width-50, height-42,
            		//left����
            		25, 42, width-50, height-42,
            		//right����
            		25, 42, width-50, height-42,
            		//up����
            		25, 42, width-50, height-42,
            };
            
            // �ָ�ͼƬ
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                	// ��ȡ��ǰ����Ĳü�����
                    int baseIndex = row * 4;
                    int cropX = cropParams[baseIndex];
                    int cropY = cropParams[baseIndex+1];
                    int cropWidth = cropParams[baseIndex+2];
                    int cropHeight = cropParams[baseIndex+3];
                    
                    // ����ԭʼ��ͼλ��
                    int srcX = col * width;
                    int srcY = row * height;
                    
                    //�����ü������ͼ
                    BufferedImage subImage = originalImage.getSubimage(
                		srcX + cropX, 
                        srcY + cropY, 
                        cropWidth, 
                        cropHeight
                    );
                    
                    // ����ָ���СͼƬ
                    String direction;
                    switch (row) {
                        case 0: direction = "down"; break;
                        case 1: direction = "left"; break;
                        case 2: direction = "right"; break;
                        case 3: direction = "up"; break;
                        default: direction = "unknown";
                    }
                    
                 // ��������ļ���·��
                    String folderPath = String.format("image/Characters/newCharacers_1");
                    File folder = new File(folderPath);

                    // ����ļ��в����ڣ����Զ�����
                    if (!folder.exists()) {
                        folder.mkdirs(); // �����༶Ŀ¼������и�Ŀ¼Ҳ�����ڣ�
                    }

                    // ��������ļ�·��
                    String filePath = String.format("%s/newCharacter_%s%d.png", folderPath, direction, col + 1);
                    File output = new File(filePath);
                    ImageIO.write(subImage, "png", output);

                }
            }
            
            System.out.println("ͼƬ�ָ���ɣ�");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
