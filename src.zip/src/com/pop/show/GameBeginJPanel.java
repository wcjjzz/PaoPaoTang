package com.pop.show;

import com.pop.controller.MusicPlayer;
import com.pop.element.ElementObj;
import com.pop.game.GameStart;
import com.pop.manager.ElementManager;
import com.pop.manager.GameElement;
import com.pop.manager.GameLoad;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;



/**
 * ��Ϸ��ʼ����
 * @author xay,drh
 */
public class GameBeginJPanel extends ShowObj implements ActionListener{
    private ImageIcon img;
    private int w;
    private int h;
    private ImageIcon apple = new ImageIcon("image/bg/apple.png");//���ƶ�����
    public GameBeginJPanel(){
        this.w = GameJFrame.GameX;//�������
        this.h = GameJFrame.GameY;//����߶�
        init();
    }
    JLabel ap=new JLabel();//���ƶ����������
    int apple_x=0;//���ƶ�ͼƬ��X����
    int apple_y=0;//���ƶ�ͼƬ��Y����
    int apple_w = apple.getIconWidth();//��ȡ���ƶ�ͼƬ�Ŀ���
    int apple_h = apple.getIconHeight();//��ȡ���ƶ�ͼƬ�ĸ߶�

    boolean onePlay=false;
  //  MusicPlayer musicPlay

    private boolean showIntroduce = false;
    private JLabel introduceLabel = null;

    @Override
    protected void go() {
        apple_x-=1;//���ƶ�ͼƬ��X����ݼ�
        apple_y-=1;;//���ƶ�ͼƬ��Y����ݼ�
        ap.setBounds(apple_x,apple_y,850,850);//�������λ��
        if (apple_x<-75){//����ݼ�λ�õ�75 �����µݼ�
            apple_x=0;
            apple_y=0;
        }
    }

    private void init(){
        this.setLayout(null);
        GameJFrame.getGameJFrame().setSize(1000,830);//��������СΪ1000x830
        
        // ֻ��ʾtitle.png�������������
        ImageIcon bgIcon = new ImageIcon("image/bg/title.png");
        bgIcon.setImage(bgIcon.getImage().getScaledInstance(1000,830,Image.SCALE_DEFAULT));
        JLabel jLabelBg = new JLabel(bgIcon);
        jLabelBg.setBounds(0,0,1000,830);

        JButton onePlayerButton = new JButton();//������Ұ�ť
        onePlayerButton.setIcon(new ImageIcon("image/bg/rect1.png"));
        onePlayerButton.setBounds(60, 250, 180, 60);//�ƶ������
        onePlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onePlay=true;
                GameBeginJPanel.this.actionPerformed(e);
            }
        });

        JButton twoPlayerButton = new JButton();//˫����Ұ�ť
        twoPlayerButton.setIcon(new ImageIcon("image/bg/rect2.png"));
        twoPlayerButton.setBounds(60, 350, 180, 60);//�ƶ������
        twoPlayerButton.addActionListener(this);

        JButton introduceButton = new JButton();
        introduceButton.setIcon(new ImageIcon("image/bg/rect3.png"));
        introduceButton.setBounds(60, 450, 180, 60);
        introduceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showIntroduce = !showIntroduce;
                if (showIntroduce) {
                    if (introduceLabel == null) {
                        ImageIcon introduceIcon = new ImageIcon("image/bg/introduce.png");
                        introduceIcon.setImage(introduceIcon.getImage().getScaledInstance(600, 600, Image.SCALE_SMOOTH));
                        introduceLabel = new JLabel(introduceIcon);
                        introduceLabel.setBounds(260, 200, 600, 600);
                    }
                    add(introduceLabel);
                    introduceLabel.setVisible(true);
                    setComponentZOrder(introduceLabel, 0);
                } else {
                    if (introduceLabel != null) {
                        introduceLabel.setVisible(false);
                    }
                }
                repaint();
            }
        });

        this.add(onePlayerButton);
        this.add(twoPlayerButton);
        this.add(introduceButton);
        this.add(jLabelBg);

        this.setVisible(true);
        this.setOpaque(true);
    }
    private static int i=0;
    @Override
    public void actionPerformed(ActionEvent e) {
        //musicPlayer.end();



        GameJFrame.getGameJFrame().remove(this);
        GameJFrame.getGameJFrame().setjPanel(new GameMainJPanel(onePlay));
        ++i;
    }
}

